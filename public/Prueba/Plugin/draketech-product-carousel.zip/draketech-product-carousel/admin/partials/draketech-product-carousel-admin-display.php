<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://www.linkedin.com/in/miguel-mariano-developer/
 * @since      1.0.0
 *
 * @package    Draketech_Product_Carousel
 * @subpackage Draketech_Product_Carousel/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
